import os
import logging
import asyncio
import httpx
import yt_dlp
from typing import Tuple, Optional
from tqdm import tqdm
from pathlib import Path
from datetime import datetime
from tenacity import retry, stop_after_attempt, wait_exponential

from .utils import is_valid_tiktok_url, extract_video_id, get_default_headers
from .exceptions import (
    InvalidURLError, VideoExtractionError, DownloadError,
    InvalidVideoIDError, NetworkError, FileSizeError
)
from .models import VideoInfo

logger = logging.getLogger(__name__)

class TikTokDownloader:
    def __init__(self, download_dir: str, max_file_size: int = 50 * 1024 * 1024):
        """تهيئة TikTokDownloader مع مجلد التحميل"""
        self.download_dir = Path(download_dir)
        self.max_file_size = max_file_size  # الحد الأقصى لحجم الملف (50MB افتراضياً)
        self.headers = get_default_headers()
        self._client = httpx.AsyncClient(
            headers=self.headers,
            follow_redirects=True,
            timeout=30.0
        )
        
    async def __aenter__(self):
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self._client.aclose()

    def _get_ydl_opts(self, video_info: VideoInfo) -> dict:
        """الحصول على خيارات yt-dlp"""
        return {
            'format': 'best[ext=mp4]',  # أفضل جودة بصيغة MP4
            'outtmpl': str(self.download_dir / f"{video_info.title}.%(ext)s"),
            'quiet': True,
            'no_warnings': True,
            'extract_flat': False,
            'http_headers': self.headers,
            'socket_timeout': 30,
            'retries': 5,
            'progress_hooks': [self._progress_hook],
            'cookiesfrombrowser': ['chrome'],  # استخدام كوكيز المتصفح للتحميل
            'extractor_args': {'tiktok': {'api_hostname': 'api16-normal-c-useast1a.tiktokv.com'}},
        }

    def _progress_hook(self, d: dict):
        """مؤشر تقدم التحميل لـ yt-dlp"""
        if d['status'] == 'downloading':
            if not hasattr(self, '_progress_bar'):
                total = d.get('total_bytes') or d.get('total_bytes_estimate', 0)
                filename = os.path.basename(d['filename'])
                self._progress_bar = tqdm(
                    total=total,
                    unit='B',
                    unit_scale=True,
                    desc=f"جاري تحميل {filename}",
                    ncols=80
                )
                self._last_downloaded = 0

            downloaded = d.get('downloaded_bytes', 0)
            delta = downloaded - self._last_downloaded
            if delta > 0:
                self._progress_bar.update(delta)
                self._last_downloaded = downloaded

            # إضافة معلومات إضافية
            speed = d.get('speed', 0)
            if speed:
                self._progress_bar.set_postfix_str(f"{speed/1024/1024:.1f} MB/s")

        elif d['status'] == 'finished':
            if hasattr(self, '_progress_bar'):
                self._progress_bar.close()
                delattr(self, '_progress_bar')
                delattr(self, '_last_downloaded')

    async def _ensure_download_dir(self) -> None:
        """التأكد من وجود مجلد التحميل"""
        try:
            self.download_dir.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            raise DownloadError(f"فشل إنشاء مجلد التحميل: {str(e)}")

    async def _extract_video_info(self, url: str, video_id: str) -> VideoInfo:
        """استخراج معلومات الفيديو باستخدام yt-dlp"""
        try:
            loop = asyncio.get_event_loop()
            with yt_dlp.YoutubeDL({'quiet': True}) as ydl:
                info = await loop.run_in_executor(None, ydl.extract_info, url, True)
                
                return VideoInfo(
                    video_id=video_id,
                    title=info.get('title', f'tiktok_video_{video_id}'),
                    url=url,
                    author=info.get('uploader'),
                    duration=info.get('duration'),
                    description=info.get('description'),
                    likes=info.get('like_count'),
                    shares=info.get('repost_count'),
                    comments=info.get('comment_count')
                )
        except Exception as e:
            logger.error(f"فشل في استخراج معلومات الفيديو: {str(e)}")
            raise VideoExtractionError(f"فشل في استخراج معلومات الفيديو: {str(e)}")

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=4, max=10),
        retry_error_cls=NetworkError
    )
    async def download(self, url: str) -> Tuple[str, str]:
        """تحميل الفيديو من تيك توك"""
        try:
            logger.info(f"بدء تحميل فيديو TikTok من الرابط: {url}")
            
            if not is_valid_tiktok_url(url):
                raise InvalidURLError("عذراً، هذا الرابط غير مدعوم")
            
            await self._ensure_download_dir()
            
            # استخراج معرف الفيديو
            video_id = await extract_video_id(url)
            if not video_id:
                raise InvalidVideoIDError("لم نتمكن من استخراج معرف الفيديو")
            
            # استخراج معلومات الفيديو
            video_info = await self._extract_video_info(url, video_id)
            
            # تحميل الفيديو
            loop = asyncio.get_event_loop()
            with yt_dlp.YoutubeDL(self._get_ydl_opts(video_info)) as ydl:
                try:
                    logger.info("جاري تحميل الفيديو...")
                    await loop.run_in_executor(None, ydl.download, [url])
                    
                    video_path = self.download_dir / f"{video_info.title}.mp4"
                    if not video_path.exists():
                        raise DownloadError("فشل تحميل الفيديو")
                    
                    # التحقق من حجم الملف
                    if video_path.stat().st_size > self.max_file_size:
                        video_path.unlink()  # حذف الملف
                        raise FileSizeError(f"حجم الفيديو يتجاوز الحد المسموح به ({self.max_file_size / 1024 / 1024:.1f}MB)")
                    
                    video_info.file_path = str(video_path)
                    video_info.size = video_path.stat().st_size
                    
                    logger.info(f"تم تحميل الفيديو بنجاح: {video_info.title}")
                    return str(video_path), video_info.title
                    
                except Exception as e:
                    logger.error(f"خطأ أثناء التحميل: {str(e)}")
                    # تنظيف الملفات في حالة الفشل
                    if video_path.exists():
                        video_path.unlink()
                    raise DownloadError(f"فشل تحميل الفيديو: {str(e)}")
                    
        except Exception as e:
            logger.error(f"خطأ أثناء عملية التحميل: {str(e)}")
            raise
