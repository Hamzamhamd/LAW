class TikTokDownloadError(Exception):
    """استثناء أساسي لأخطاء تحميل TikTok"""
    pass

class InvalidURLError(TikTokDownloadError):
    """يتم رفعه عندما يكون الرابط غير صالح"""
    pass

class VideoExtractionError(TikTokDownloadError):
    """يتم رفعه عندما يفشل استخراج معلومات الفيديو"""
    pass

class DownloadError(TikTokDownloadError):
    """يتم رفعه عندما يفشل تحميل الفيديو"""
    pass

class InvalidVideoIDError(TikTokDownloadError):
    """يتم رفعه عندما يفشل استخراج معرف الفيديو"""
    pass

class NetworkError(TikTokDownloadError):
    """يتم رفعه عند حدوث مشكلة في الاتصال بالإنترنت"""
    pass

class FileSizeError(TikTokDownloadError):
    """يتم رفعه عندما يتجاوز حجم الملف الحد المسموح به"""
    pass
