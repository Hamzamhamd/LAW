import re
import logging
from typing import Optional
import httpx
from tenacity import retry, stop_after_attempt, wait_exponential

from .exceptions import InvalidURLError, NetworkError

logger = logging.getLogger(__name__)

def is_valid_tiktok_url(url: str) -> bool:
    """التحقق من صحة رابط تيك توك"""
    patterns = [
        r'https?://(?:www\.)?tiktok\.com/@[\w\.-]+/video/\d+',
        r'https?://(?:www\.)?tiktok\.com/[@\w\.-]+/\w+/\d+',
        r'https?://(?:www\.)?vm\.tiktok\.com/\w+',
        r'https?://(?:www\.)?vt\.tiktok\.com/\w+',
        r'https?://(?:www\.)?tiktok\.com/t/\w+',
        r'https?://(?:m\.)?tiktok\.com/v/\d+',
        r'https?://(?:www\.)?tiktok\.com/\w+',
        r'https?://(?:www\.)?douyin\.com/video/\d+'
    ]
    
    url = url.strip()
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url
        
    return any(re.match(pattern, url, re.IGNORECASE) for pattern in patterns)

@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=4, max=10),
    retry_error_cls=NetworkError
)
async def extract_video_id(url: str) -> Optional[str]:
    """استخراج معرف الفيديو من الرابط"""
    try:
        # محاولة استخراج معرف الفيديو من الرابط المباشر
        video_id_match = re.search(r'/video/(\d+)', url)
        if video_id_match:
            return video_id_match.group(1)
        
        # إذا كان الرابط مختصر، نتبع إعادة التوجيه للحصول على الرابط الكامل
        async with httpx.AsyncClient(follow_redirects=True, timeout=30.0) as client:
            response = await client.head(url)
            final_url = str(response.url)
            video_id_match = re.search(r'/video/(\d+)', final_url)
            if video_id_match:
                return video_id_match.group(1)
                
    except httpx.HTTPError as e:
        logger.error(f"خطأ في الاتصال بالشبكة: {str(e)}")
        raise NetworkError(f"فشل الاتصال بالشبكة: {str(e)}")
    except Exception as e:
        logger.error(f"خطأ في استخراج معرف الفيديو: {str(e)}")
        
    return None

def get_default_headers():
    """إرجاع الترويسات الافتراضية للطلبات"""
    return {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Referer': 'https://www.tiktok.com/'
    }
