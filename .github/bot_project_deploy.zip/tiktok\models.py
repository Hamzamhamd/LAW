from dataclasses import dataclass
from typing import Optional
from datetime import datetime

@dataclass
class VideoInfo:
    """فئة لتخزين معلومات فيديو TikTok"""
    video_id: str
    title: str
    url: str
    author: Optional[str] = None
    duration: Optional[int] = None
    file_path: Optional[str] = None
    size: Optional[int] = None
    created_at: datetime = datetime.now()
    description: Optional[str] = None
    likes: Optional[int] = None
    shares: Optional[int] = None
    comments: Optional[int] = None
